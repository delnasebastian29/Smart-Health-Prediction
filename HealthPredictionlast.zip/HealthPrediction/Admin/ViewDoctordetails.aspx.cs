﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using HealthPrediction.Class;

namespace HealthPrediction.Admin
{
    public partial class ViewDoctordetails : System.Web.UI.Page
    {
       

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        HealthPrediction.Class.DoctorRegClass objDviews = new HealthPrediction.Class.DoctorRegClass();
        protected void Page_Load(object sender, EventArgs e)
        {
            LoadData();
        }
        private void LoadData()
        {
            DataTable dtReg = new DataTable();
             DoctorRegClass objDview= new DoctorRegClass();
            dtReg =objDview.DoctorView();
            if (dtReg.Rows.Count > 0)
            {
                gvvies.DataSource = dtReg;
                gvvies.DataBind();
            }
        }

    }

}