﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using HealthPrediction.Class;

namespace HealthPrediction.Admin
{
    public partial class ViewFeedback : System.Web.UI.Page
    {
        protected void gv_fd_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        HealthPrediction.Class.HealthPredictionClass objFdview = new HealthPrediction.Class.HealthPredictionClass();
        protected void Page_Load(object sender, EventArgs e)
        {
            LoadData();
        }
        private void LoadData()
        {
            DataTable dtReg = new DataTable();
            ViewClass sObj = new ViewClass();
            dtReg = sObj.ExecuteFSelectQueries();
            if (dtReg.Rows.Count > 0)
            {
                gv_fd.DataSource = dtReg;
                gv_fd.DataBind();
            }
        }

    }
}