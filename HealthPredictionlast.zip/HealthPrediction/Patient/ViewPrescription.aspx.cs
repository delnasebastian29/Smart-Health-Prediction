﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using HealthPrediction.Class;

namespace HealthPrediction.Patient
{
    public partial class ViewPrescription : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        protected void gv_presview_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private void LoadData()
        {
            DataTable dtReg = new DataTable();
            HealthPrediction.Class.HealthPredictionClass objPreview = new HealthPrediction.Class.HealthPredictionClass();
            dtReg = objPreview.PrescView();
            if (dtReg.Rows.Count > 0)
            {
                gv_presview.DataSource = dtReg;
                gv_presview.DataBind();
            }
        }
    }
}