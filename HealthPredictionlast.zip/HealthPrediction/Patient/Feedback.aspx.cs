﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HealthPrediction.Class;

namespace HealthPrediction.Patient
{
    public partial class Feedback : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        //protected void btnsnds(object sender, EventArgs e)
        //{
        //   // HealthPrediction.Class.HealthPredictionClass objfd = new HealthPrediction.Class.HealthPredictionClass();
        //    //   HealthPredictionClass objReg = new HealthPredictionClass();
            
            
        //    objfd.Feedback = txtfdb.Text;
        //    objfd.Pid = Convert.ToString(Session["PatientId"]);
        //    objfd.InsertFeedback();

        //}

        protected void btnsd_Click(object sender, EventArgs e)
        {
            HealthPrediction.Class.HealthPredictionClass objfd = new HealthPrediction.Class.HealthPredictionClass();
            //   HealthPredictionClass objReg = new HealthPredictionClass();


            objfd.Feedback = txtfdb.Text;
            objfd.Pid = Convert.ToString(Session["PatientId"]);
            objfd.InsertFeedback();
            lblmg.Text = "Send Message";
            objfd.Fdmsg = "";


        }

        protected void btncancel_Click(object sender, EventArgs e)
        {
            txtfdb.Text = "";
            lblmg.Text = "";
        }
    }
}