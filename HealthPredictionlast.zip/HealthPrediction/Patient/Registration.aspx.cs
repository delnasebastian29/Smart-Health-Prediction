﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HealthPrediction.Class;

namespace HealthPredictionClass.Patient
{
    public partial class Registration : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void RadioButton_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void btnsave_Click(object sender, EventArgs e)
        {
            //   HealthPrediction objReg = new HealthPrediction();
            HealthPrediction.Class.HealthPredictionClass objReg = new HealthPrediction.Class.HealthPredictionClass();
         //   HealthPredictionClass objReg = new HealthPredictionClass();
            objReg.Pname = txtp_name.Text;
            objReg.Pgender = radiomale.Text;
            objReg.Pgender = radiofemale.Text;
            objReg.Paddress = txtp_address.Text;
            objReg.Page = txtp_age.Text;
            objReg.Pbldg = txtp_bldg.Text;
            objReg.Pemail = txtp_email.Text;
            objReg.Pmobileno = txtp_mobileno.Text;
            objReg.Pusname = txtp_uname.Text;
            objReg.Ppass = txtp_password.Text;
            objReg.InsertPatient();
        }

        protected void btncancel_Click(object sender, EventArgs e)
        {
            txtp_name.Text = "";
            txtp_address.Text = "";
            txtp_age.Text = "";
            txtp_bldg.Text = "";
            txtp_email.Text = "";
            txtp_mobileno.Text = "";
            txtp_uname.Text = "";
            txtp_password.Text = "";

        }
    }
}