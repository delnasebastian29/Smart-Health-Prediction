﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HealthPrediction.Class;

namespace HealthPrediction.Doctor
{
    public partial class DoctorReg : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void RadioButton_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            HealthPrediction.Class.DoctorRegClass objReg = new HealthPrediction.Class.DoctorRegClass();
            objReg.Dname = txtd_name.Text;
            objReg.Dgender = radiomale.Text;
            objReg.Dgender = radiofemale.Text;
            objReg.Daddress = txtd_address.Text;
            objReg.Ddob = Convert.ToDateTime( txtdob.Text);
            objReg.Dquaification = txtd_qualification.Text;
            objReg.Ddepartment = Department.SelectedItem.Text;
            objReg.Demail = txtd_email.Text;
            objReg.Dmobileno = txtd_mobileno.Text;
            objReg.Duname = txtd_uname.Text;
            objReg.Dpass = txtd_pass.Text;
            objReg.InsertDoctor();
        }

        protected void btncancel_Click(object sender, EventArgs e)
        {
            txtd_name.Text = "";
            txtd_address.Text = "";
            txtdob.Text = "";
            txtd_qualification.Text = "";
            txtd_email.Text = "";
            txtd_mobileno.Text = "";
            txtd_uname.Text = "";
            txtd_pass.Text = "";
        }
    }
}
        