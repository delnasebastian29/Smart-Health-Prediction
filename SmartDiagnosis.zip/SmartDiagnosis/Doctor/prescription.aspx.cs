﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using SmartDiagnosis.Class;

namespace SmartDiagnosis.Doctor
{
    public partial class prescription : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindPatient();
            }

        }

        protected void btnsrh_Click(object sender, EventArgs e)
        {
            BindPatient();
            gv_pres.Visible = true;

        }

        protected void gv_pres_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Message")
            {
                int rowIndex = Convert.ToInt32(e.CommandArgument);
                GridViewRow row = gv_pres.Rows[rowIndex];
                // Session["tcp_id"] = ((HiddenField)gv_tpc.Rows[rowIndex].FindControl("hdnPId")).Value;

                Session["PatientId"] = row.Cells[0].Text;

                /* GridViewRow row = gv_tpc.Rows[rowIndex];  //(GridViewRow)(((Button)e.CommandSource).NamingContainer);
                 HiddenField hdnPreviousState = (HiddenField)row.Cells[1].FindControl("hdnPId");
                 string previousState = hdnPreviousState.Value;*/
                lbldn.Visible = true;
                txtpres.Visible = true;
                lblmn.Visible = true;
                txtmn.Visible = true;
                lbldes.Visible = true;
                txtdes.Visible = true;
                btnsnd.Visible = true;
                lblmsge.Visible = true;
                btncls.Visible = true;


            }

        }
        private void BindPatient()
        {
            DataTable dtReg = new DataTable();
            SmartDiagnosis.Class.HealthClass objSearch = new SmartDiagnosis.Class.HealthClass();
            //   HealthPredictionClass objReg = new HealthPredictionClass();
            objSearch.Pname = txtpatientname.Text;
            objSearch.Paddress = txtaddresss.Text;
            objSearch.Pemail = txteml.Text;
            objSearch.Pmobileno = txteml.Text;
            dtReg = objSearch.SearchPatient();
            if (dtReg.Rows.Count > 0)
            {
                gv_pres.DataSource = dtReg;
                gv_pres.DataBind();

            }
        }

        protected void btnsnd_Click(object sender, EventArgs e)
        {
            SmartDiagnosis.Class.HealthClass objpres = new SmartDiagnosis.Class.HealthClass();
            //   HealthPredictionClass objReg = new HealthPredictionClass();
            objpres.Diseasename = txtpres.Text;
            objpres.Medicinename = txtmn.Text;
            objpres.Description = txtdes.Text;

            objpres.Pid = Convert.ToString(Session["PatientId"]);
            objpres.Did = Convert.ToString(Session["DoctorId"]);
            objpres.InsertPrescription();
            lblmsge.Text = "Send Message";
            objpres.Diseasename = "";
            objpres.Medicinename = "";
            objpres.Description = "";



        }

        protected void btncls_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Doctor/DoctorHome.aspx");
        }
    }
    }
    
