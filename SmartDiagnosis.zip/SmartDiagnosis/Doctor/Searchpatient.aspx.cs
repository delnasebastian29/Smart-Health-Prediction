﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using SmartDiagnosis.Class;

namespace SmartDiagnosis.Doctor
{
    public partial class Searchpatient : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindPatients();
            }

        }

        protected void btnsearch_Click(object sender, EventArgs e)
        {
            BindPatients();
            gv_tpc.Visible = true;

        }

        protected void gv_tpc_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Reply")
            {
                int rowIndex = Convert.ToInt32(e.CommandArgument);
                GridViewRow row = gv_tpc.Rows[rowIndex];
                // Session["tcp_id"] = ((HiddenField)gv_tpc.Rows[rowIndex].FindControl("hdnPId")).Value;

                Session["PatientId"] = row.Cells[0].Text;

                /* GridViewRow row = gv_tpc.Rows[rowIndex];  //(GridViewRow)(((Button)e.CommandSource).NamingContainer);
                 HiddenField hdnPreviousState = (HiddenField)row.Cells[1].FindControl("hdnPId");
                 string previousState = hdnPreviousState.Value;*/

                txtreply.Visible = true;
                lbldi.Visible = true;
                lblmseg.Visible = true;
                btnsend.Visible = true;
                btncl.Visible = true;

            }


        

    }
        private void BindPatients()
        {
            DataTable dtReg = new DataTable();
            SmartDiagnosis.Class.HealthClass objSearch = new SmartDiagnosis.Class.HealthClass();
            //   HealthPredictionClass objReg = new HealthPredictionClass();
            objSearch.Pname = txtname.Text;
            objSearch.Paddress = txtaddress.Text;
            objSearch.Pemail = txtemailid.Text;
            objSearch.Pmobileno = txtmobileno.Text;
            dtReg = objSearch.SearchPatient();
            if (dtReg.Rows.Count > 0)
            {
                gv_tpc.DataSource = dtReg;
                gv_tpc.DataBind();

            }
        }

        protected void btnsend_Click(object sender, EventArgs e)
        {
            SmartDiagnosis.Class.HealthClass objpredict = new SmartDiagnosis.Class.HealthClass();
            //   HealthPredictionClass objReg = new HealthPredictionClass();
            objpredict.Rply = txtreply.Text;

            objpredict.Pid = Convert.ToString(Session["PatientId"]);
            objpredict.Did = Convert.ToString(Session["DoctorId"]);
            objpredict.InsertPrediction();
            lblmseg.Text = "Send Message";
            objpredict.Rply = "";
        }

        protected void btncl_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Doctor/DoctorHome.aspx");

        }

        protected void gv_tpc_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}