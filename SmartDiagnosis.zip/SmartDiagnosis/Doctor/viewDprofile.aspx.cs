﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using SmartDiagnosis.Class;

namespace SmartDiagnosis.Doctor
{
    public partial class viewDprofile : System.Web.UI.Page
    {
        DocRegClass objviews = new DocRegClass();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (HttpContext.Current.Session["DoctorId"] == null)
            {
                Response.Redirect("~/Doctor/DoctorHome.Master");
            }
            else if (!IsPostBack)
            {
                DataTable dt = new DataTable();
                objviews.Duname = Convert.ToString(Session["DoctorId"]);
                dt = objviews.showdata();
                if (dt.Rows.Count > 0)
                {
                    dvviews.DataSource = dt;
                    dvviews.DataBind();

                }
            }
        }

        protected void dvview_PageIndexChanging(object sender, DetailsViewPageEventArgs e)
        {

        }
    }
}