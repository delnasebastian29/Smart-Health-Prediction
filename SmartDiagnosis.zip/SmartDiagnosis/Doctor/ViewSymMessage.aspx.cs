﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using SmartDiagnosis.Class;

namespace SmartDiagnosis.Doctor
{
    public partial class ViewSymMessage : System.Web.UI.Page
    {
        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        SmartDiagnosis.Class.DocRegClass objMsgview = new SmartDiagnosis.Class.DocRegClass();
        protected void Page_Load(object sender, EventArgs e)
        {
            LoadData();

        }
        private void LoadData()
        {
            DataTable dtReg = new DataTable();
            DocRegClass objMsgview = new DocRegClass();
            dtReg = objMsgview.MessageView();
            if (dtReg.Rows.Count > 0)
            {
                gv_msg.DataSource = dtReg;
                gv_msg.DataBind();
            }
        }


    }
}