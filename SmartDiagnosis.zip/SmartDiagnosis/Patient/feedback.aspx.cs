﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SmartDiagnosis.Class;

namespace SmartDiagnosis.Patient
{
    public partial class feedback : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnsd_Click(object sender, EventArgs e)
        {
            SmartDiagnosis.Class.HealthClass objfd = new SmartDiagnosis.Class.HealthClass();
            //   HealthPredictionClass objReg = new HealthPredictionClass();


            objfd.Feedback = txtfdb.Text;
            objfd.Pid = Convert.ToString(Session["PatientId"]);
            objfd.InsertFeedback();
            lblmg.Text = "Send Message";
            objfd.Fdmsg = "";


        }

        protected void btncancels_Click(object sender, EventArgs e)
        {
            txtfdb.Text = "";
        }
    }
}
