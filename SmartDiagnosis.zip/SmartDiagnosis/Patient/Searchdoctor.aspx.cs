﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using SmartDiagnosis.Class;

namespace SmartDiagnosis.Patient
{
    public partial class Searchdoctor : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindDoctors();
            }
        }

        protected void btnsearch_Click(object sender, EventArgs e)
        {
            BindDoctors();
            gv_sd.Visible = true;

        }

        protected void gv_sd_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Message")
            {
                int rowIndex = Convert.ToInt32(e.CommandArgument);
                GridViewRow row = gv_sd.Rows[rowIndex];
                // Session["tcp_id"] = ((HiddenField)gv_tpc.Rows[rowIndex].FindControl("hdnPId")).Value;

                Session["DoctorId"] = row.Cells[0].Text;

                /* GridViewRow row = gv_tpc.Rows[rowIndex];  //(GridViewRow)(((Button)e.CommandSource).NamingContainer);
                 HiddenField hdnPreviousState = (HiddenField)row.Cells[1].FindControl("hdnPId");
                 string previousState = hdnPreviousState.Value;*/
                txtsymptom.Visible = true;
                lblspms.Visible = true;
                lblmsg.Visible = true;
                btnsend.Visible = true;
                btncanl.Visible = true;
            }
        }
        private void BindDoctors()
        {
            DataTable dtReg = new DataTable();
            SmartDiagnosis.Class.DocRegClass objDocsearch = new SmartDiagnosis.Class.DocRegClass();
            //   HealthPredictionClass objReg = new HealthPredictionClass();
            objDocsearch.Ddepartment = Departments.SelectedItem.Text;
            //objDocsearch.Ddepartment = txtdpt.Text;
            objDocsearch.Dname = txtnme.Text;
            objDocsearch.Demail = txtemlid.Text;
            objDocsearch.Dmobileno = txtmob.Text;
            dtReg = objDocsearch.SearchDoctor();
            if (dtReg.Rows.Count > 0)
            {
                gv_sd.DataSource = dtReg;
                gv_sd.DataBind();

            }


        }

        protected void btnsend_Click(object sender, EventArgs e)
        {
            SmartDiagnosis.Class.DocRegClass objmsg = new SmartDiagnosis.Class.DocRegClass();
            //   HealthPredictionClass objReg = new HealthPredictionClass();
            objmsg.Msg = txtsymptom.Text;

            objmsg.D_id = Convert.ToString(Session["DoctorId"]);
            objmsg.P_id = Convert.ToString(Session["PatientId"]);
            objmsg.InsertSymptom();
            lblmsg.Text = "Send Message";
            objmsg.Msg = "";
            //Response.Redirect("~/Patient/PatientHome.aspx");
        }
        

        protected void btncanl_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Patient/PatientHome.aspx");
        }
    }
}
    
