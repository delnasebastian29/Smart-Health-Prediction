﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using SmartDiagnosis.Class;

namespace SmartDiagnosis.Patient
{
    public partial class Replyview : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        protected void gv_reply_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private void LoadData()
        {
            DataTable dtReg = new DataTable();
            SmartDiagnosis.Class.HealthClass objReplyview = new SmartDiagnosis.Class.HealthClass();
            dtReg = objReplyview.ReplyView();
            if (dtReg.Rows.Count > 0)
            {
                gv_reply.DataSource = dtReg;
                gv_reply.DataBind();
            }
        }
    }
}