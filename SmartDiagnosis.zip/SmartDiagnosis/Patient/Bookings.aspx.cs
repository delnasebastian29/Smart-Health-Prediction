﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SmartDiagnosis.Class;

namespace SmartDiagnosis.Patient
{
    public partial class Bookings : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btncancel_Click1(object sender, EventArgs e)
        {
            txtapntdate.Text = "";
            txtapnttime.Text = "";

        }

        protected void btnsave_Click(object sender, EventArgs e)
        {
            SmartDiagnosis.Class.BookingsClass objBook = new SmartDiagnosis.Class.BookingsClass();
            //   HealthPredictionClass objReg = new HealthPredictionClass();
            objBook.Dept = Deptsname.SelectedItem.Text;
            objBook.Apntmntdate = txtapntdate.Text;
            objBook.Apntmnttime = txtapnttime.Text;
            objBook.Pid = Convert.ToInt32(Session["PatientId"]);
            objBook.InsertBooking();

        }
    }
}