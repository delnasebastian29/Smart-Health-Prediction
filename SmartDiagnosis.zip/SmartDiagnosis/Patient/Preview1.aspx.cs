﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using SmartDiagnosis.Class;

namespace SmartDiagnosis.Patient
{
    public partial class Preview1 : System.Web.UI.Page
    {
        SmartDiagnosis.Class.HealthClass objVw1 = new SmartDiagnosis.Class.HealthClass();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (HttpContext.Current.Session["PatientId"] == null)
            {
                Response.Redirect("~/Patient/PatientHome.aspx");
            }
            else if (!IsPostBack)
            {
                DataTable dt = new DataTable();
                objVw1.Pid = Convert.ToString(Session["PatientId"]);
                dt = objVw1.viewpres1();
                if (dt.Rows.Count > 0)
                {
                    GridView1.DataSource = dt;
                    GridView1.DataBind();
                }
            }
        }

    }
    }
