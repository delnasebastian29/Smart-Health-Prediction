﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using SmartDiagnosis.Class;


namespace SmartDiagnosis.Admin
{
    public partial class viewDoctordetails : System.Web.UI.Page
    {
     
        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        SmartDiagnosis.Class.DocRegClass objDviews = new SmartDiagnosis.Class.DocRegClass();
        protected void Page_Load(object sender, EventArgs e)
        {
            LoadData();
        }
        private void LoadData()
        {
            DataTable dtReg = new DataTable();
            DocRegClass objDview = new DocRegClass();
            dtReg = objDview.DoctorView();
            if (dtReg.Rows.Count > 0)
            {
                gvvies.DataSource = dtReg;
                gvvies.DataBind();
            }
        }

    }
}