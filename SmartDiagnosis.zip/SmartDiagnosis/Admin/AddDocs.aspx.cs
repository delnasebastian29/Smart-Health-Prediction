﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SmartDiagnosis.Class;

namespace SmartDiagnosis.Admin
{
    public partial class AddDocs : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnsave_Click(object sender, EventArgs e)
        {
            SmartDiagnosis.Class.AddDocsClass objadd = new SmartDiagnosis.Class.AddDocsClass();
            //   HealthPredictionClass objReg = new HealthPredictionClass();
            objadd.Docname = txtdocname.Text;
            //objadd.Docgender = radiomale.Text;
            //objadd.Docgender = radiofemale.Text;
            if (radiomale.Checked)
            {
                objadd.Docgender = radiomale.Text;
            }
            else if (radiofemale.Checked)
            {
                objadd.Docgender = radiofemale.Text;
            }
            objadd.Docaddress = txtdocaddress.Text;
            objadd.Docquaification = txtqualification.Text;
            objadd.Docdepartment = Department.SelectedItem.Text;
            objadd.Docemail = txtdocemailid.Text;
            objadd.Docmobileno = txtdocmobieno.Text;
            objadd.InsertAdddoctor();
            //Response.Redirect("~/Admin/Adminhome.aspx");
        }

        protected void btncancl_Click(object sender, EventArgs e)
        {
            txtdocname.Text = "";
            txtdocaddress.Text = "";
            txtqualification.Text = "";

            txtdocemailid.Text = "";
            txtdocmobieno.Text = "";

        }
    }
    }
