﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace SmartDiagnosis.Admin
{
    public partial class Adminlogin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnsave_Click(object sender, EventArgs e)
        {
            if (txtuname.Text == "admin" && txtpassd.Text == "admin")
            {



                lblmsg.Text = " Sucess.";
                Response.Redirect("~/Admin/AdminHome.aspx");

            }
            else
            {
                lblmsg.Text = " Incorrect Try again..!!";
            }


        }

        protected void btcl_Click(object sender, EventArgs e)
        {
            txtuname.Text = "";
            txtpassd.Text = "";
            lblmsg.Text = "";
        }
    }
    }
