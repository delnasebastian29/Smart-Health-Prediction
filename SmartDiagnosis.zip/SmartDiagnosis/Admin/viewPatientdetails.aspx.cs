﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using SmartDiagnosis.Class;

namespace SmartDiagnosis.Admin
{
    public partial class viewPatientdetails : System.Web.UI.Page
    {
        
        SmartDiagnosis.Class.HealthClass objView = new SmartDiagnosis.Class.HealthClass();
        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        protected void Page_Load(object sender, EventArgs e)
        {
            LoadData();
        }
        private void LoadData()
        {
            DataTable dtReg = new DataTable();
            ViewClass sObj = new ViewClass();
            dtReg = sObj.ExecuteSelectQueries();
            if (dtReg.Rows.Count > 0)
            {
                gvview.DataSource = dtReg;
                gvview.DataBind();
            }
        }
    }
}