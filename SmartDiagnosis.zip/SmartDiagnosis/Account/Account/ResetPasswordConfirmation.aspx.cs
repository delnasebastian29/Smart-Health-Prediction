﻿using System.Web.UI;

namespace SmartDiagnosis.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}