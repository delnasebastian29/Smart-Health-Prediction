﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;


namespace SmartDiagnosis.Class
{
    public class HealthClass
    {
        string ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["myConn"].ConnectionString;
        SqlConnection con;
        public void OpenConection()
        {
            con = new SqlConnection(ConnectionString);
            con.Open();
        }
        public void CloseConnection()
        {
            con.Close();
        }

        public void ExecuteQueries(string Query_)
        {
            // Whenever you want to execute a query, like an insert, update or delete
            //query then simply call this function 
            //using the object of a class and pass your query to the function
            SqlCommand cmd = new SqlCommand(Query_, con);
            cmd.ExecuteNonQuery();
        }


        private string pname;
        private string pgender;
        private string paddress;
        private string page;
        private string pbldg;
        private string pemail;
        private string pmobileno;
        private string pusname;
        private string ppass;
        private string pid;
        private string did;
        private string rply;
        private string diseasename;
        private string medicinename;
        private string description;
        private string feedback;
        private string fdmsg;

        public string Pname
        {
            get
            {
                return pname;
            }

            set
            {
                pname = value;
            }
        }

        public string Pgender
        {
            get
            {
                return pgender;
            }

            set
            {
                pgender = value;
            }
        }

        public string Paddress
        {
            get
            {
                return paddress;
            }

            set
            {
                paddress = value;
            }
        }

        public string Page
        {
            get
            {
                return page;
            }

            set
            {
                page = value;
            }
        }

        public string Pbldg
        {
            get
            {
                return pbldg;
            }

            set
            {
                pbldg = value;
            }
        }

        public string Pemail
        {
            get
            {
                return pemail;
            }

            set
            {
                pemail = value;
            }
        }

        public string Pmobileno
        {
            get
            {
                return pmobileno;
            }

            set
            {
                pmobileno = value;
            }
        }

        public string Pusname
        {
            get
            {
                return pusname;
            }

            set
            {
                pusname = value;
            }
        }

        public string Ppass
        {
            get
            {
                return ppass;
            }

            set
            {
                ppass = value;
            }
        }

        public string Pid
        {
            get
            {
                return pid;
            }

            set
            {
                pid = value;
            }
        }

        public string Did
        {
            get
            {
                return did;
            }

            set
            {
                did = value;
            }
        }

        public string Rply
        {
            get
            {
                return rply;
            }

            set
            {
                rply = value;
            }
        }

        public string Diseasename
        {
            get
            {
                return diseasename;
            }

            set
            {
                diseasename = value;
            }
        }

        public string Medicinename
        {
            get
            {
                return medicinename;
            }

            set
            {
                medicinename = value;
            }
        }

        public string Description
        {
            get
            {
                return description;
            }

            set
            {
                description = value;
            }
        }

        public string Feedback
        {
            get
            {
                return feedback;
            }

            set
            {
                feedback = value;
            }
        }

        public string Fdmsg
        {
            get
            {
                return fdmsg;
            }

            set
            {
                fdmsg = value;
            }
        }



        public void InsertPatient()
    {
        OpenConection();
        SqlCommand command = new SqlCommand("Select max(p_id) from patientregi ", con);
        int p_id;
        object cMax = command.ExecuteScalar();
        if (cMax != DBNull.Value)
        {
            p_id = (int)cMax;
            p_id++;
        }
        else
        {
            p_id = 1;
        }


        string qry = "insert into patientregi values (" + p_id + ",@p_name,@p_gender,@p_address,@p_age,@p_bldg,@p_email,@p_mobileno,GETDATE(),@p_username,@p_password);";
        SqlCommand cmd = new SqlCommand(qry, con);
        cmd.Parameters.AddWithValue("@p_name", pname);
        cmd.Parameters.AddWithValue("@p_gender", pgender);
        cmd.Parameters.AddWithValue("@p_address", paddress);
        cmd.Parameters.AddWithValue("@p_age", page);
        cmd.Parameters.AddWithValue("@p_bldg", pbldg);
        cmd.Parameters.AddWithValue("@p_email", pemail);
        cmd.Parameters.AddWithValue("@p_mobileno", pmobileno);
        cmd.Parameters.AddWithValue("@p_username", pusname);
        cmd.Parameters.AddWithValue("@p_password", ppass);
        //  cmd.Parameters.AddWithValue("@sysdt", );


        cmd.ExecuteNonQuery();
    }
        public DataTable SearchPatient()
        {
            OpenConection();
            string condition = string.Empty;
            condition += (!string.IsNullOrEmpty(pid) ? " and p_id = @p_id" : string.Empty);
            condition += (!string.IsNullOrEmpty(pname) ? " and p_name like @p_username" : string.Empty);
            condition += (!string.IsNullOrEmpty(paddress) ? " and p_address like @p_addess " : string.Empty);
            condition += (!string.IsNullOrEmpty(pmobileno) ? " and p_mobileno=@p_pmobile " : string.Empty);
            condition += (!string.IsNullOrEmpty(pemail) ? " and p_email=@p_email " : string.Empty);


            string qry2 = "Select * from patientregi where 1=1 " + condition;
            SqlCommand cmd = new SqlCommand(qry2, con);
            cmd.Parameters.AddWithValue("@p_id", '%' + pid + '%');
            cmd.Parameters.AddWithValue("@p_username", '%' + pname + '%');
            cmd.Parameters.AddWithValue("@p_addess", '%' + paddress + '%');
            cmd.Parameters.AddWithValue("@p_email", pemail);
            cmd.Parameters.AddWithValue("@p_pmobile", pmobileno);


            cmd.ExecuteNonQuery();

            DataTable dtReg = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dtReg);
            CloseConnection();
            return dtReg;

        }
        public void InsertPrediction()
        {
            OpenConection();
            SqlCommand command = new SqlCommand("Select max(reply_id) from diseaseprediction_rslt ", con);
            int reply_id;
            object cMax = command.ExecuteScalar();
            if (cMax != DBNull.Value)
            {
                reply_id = (int)cMax;
                reply_id++;
            }
            else
            {
                reply_id = 1;
            }
           
            string qry = "insert into diseaseprediction_rslt values (" + reply_id + ",@pid,@did,GETDATE(),@prediction_rslt);";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@pid", pid);
            cmd.Parameters.AddWithValue("@did", did);
            cmd.Parameters.AddWithValue("@prediction_rslt", rply);
           // cmd.Parameters.AddWithValue("@date", date);


            cmd.ExecuteNonQuery();
        }
        public void InsertPrescription()
        {
            OpenConection();
            SqlCommand command = new SqlCommand("Select max(pres_id) from prescription_details ", con);
            int pres_id;
            object cMax = command.ExecuteScalar();
            if (cMax != DBNull.Value)
            {
                pres_id = (int)cMax;
                pres_id++;
            }
            else
            {
                pres_id = 1;
            }
            string qry = "insert into prescription_details values (" + pres_id + ",@pid,@did,GETDATE(),@disease_name,@medicinename_dosage,@description);";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@pid", pid);
            cmd.Parameters.AddWithValue("@did", did);
            cmd.Parameters.AddWithValue("@disease_name", diseasename);
            cmd.Parameters.AddWithValue("@medicinename_dosage", medicinename);
            cmd.Parameters.AddWithValue("@description", description);



            cmd.ExecuteNonQuery();
        }
        public DataTable showdata()
        {
            OpenConection();
            string qry2 = "select * from patientregi where  p_id=@p_username";
            SqlCommand cmd = new SqlCommand(qry2, con);
            cmd.Parameters.AddWithValue("@p_username", pusname);

            cmd.ExecuteNonQuery();

            DataTable dtReg = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dtReg);
            CloseConnection();
            return dtReg;

        }
        public DataTable ReplyView()
        {

            OpenConection();
            DataTable dtReg = new DataTable();

            SqlCommand cmd = new SqlCommand("Select * from diseaseprediction_rslt", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dtReg);
            CloseConnection();
            return dtReg;
        }
        public DataTable PrescView()
        {

            OpenConection();
            DataTable dtReg = new DataTable();

            SqlCommand cmd = new SqlCommand("Select * from prescription_details", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dtReg);
            CloseConnection();
            return dtReg;
        }
        public void InsertFeedback()
        {
            OpenConection();
            SqlCommand command = new SqlCommand("Select max(f_id) from feedback_tbl ", con);
            int f_id;
            object cMax = command.ExecuteScalar();
            if (cMax != DBNull.Value)
            {
                f_id = (int)cMax;
                f_id++;
            }
            else
            {
                f_id = 1;
            }
            string qry = "insert into feedback_tbl values (" + f_id + ",@pid,GETDATE(),@feedbacks);";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@pid", pid);
            cmd.Parameters.AddWithValue("@feedbacks", feedback);



            cmd.ExecuteNonQuery();
        }
        public DataTable viewrply1()
        {

            OpenConection();
            //string qry2 = " select rpl.p_id,rpl.d_id,com.reply_date,rpl.prediction_rslt  from " +
            //"diseaseprediction_rslt rpl left outer join Symptom_msg com on rpl.msg_id= com.msg_id where p_id=@p_id";
            string qry2 = "select rpl.p_id,rpl.d_id,rpl.reply_date,rpl.prediction_rslt  from " +
            "diseaseprediction_rslt rpl left outer join Symptom_msg com on rpl.reply_id = com.msg_id where rpl.p_id = @p_id;";
            //string qry2 = " select rpl.p_id,rpl.d_id,com.msg_date,usr.d_name,rpl.prediction_rslt,rpl.reply_date from diseaseprediction_rslt rpl  left outer join Symptom_msg com on rpl.reply_id = com.msg_id left outer join doctorregi usr on usr.d_id = @d_id where rpl.p_id =@p_id";
            SqlCommand cmd = new SqlCommand(qry2, con);
            cmd.Parameters.AddWithValue("@p_id", pid);
            //cmd.Parameters.AddWithValue("@d_id", did);


            cmd.ExecuteNonQuery();

            DataTable dtReg = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dtReg);
            CloseConnection();
            return dtReg;



        }
        public DataTable viewpres1()
        {

            OpenConection();
            //string qry2 = " select rpl.p_id,rpl.d_id,com.reply_date,rpl.prediction_rslt  from " +
            //"diseaseprediction_rslt rpl left outer join Symptom_msg com on rpl.msg_id= com.msg_id where p_id=@p_id";
            string qry2 = " select rpl.p_id,rpl.d_id,rpl.pres_date,rpl.disease_name,rpl.medicinename_dosage,rpl.description from " + 
                "prescription_details rpl left outer join diseaseprediction_rslt com on rpl.pres_id = com.reply_id where rpl.p_id =@p_id";
            SqlCommand cmd = new SqlCommand(qry2, con);
            cmd.Parameters.AddWithValue("@p_id", pid);

            //cmd.Parameters.AddWithValue("@d_id", did);
            cmd.ExecuteNonQuery();

            DataTable dtReg = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dtReg);
            CloseConnection();
            return dtReg;



        }

    }
}
