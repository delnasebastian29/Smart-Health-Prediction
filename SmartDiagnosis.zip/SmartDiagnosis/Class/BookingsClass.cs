﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;


namespace SmartDiagnosis.Class
{
    public class BookingsClass
    {
        string ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["myConn"].ConnectionString;
        SqlConnection con;
        public void OpenConection()
        {
            con = new SqlConnection(ConnectionString);
            con.Open();
        }

        public void CloseConnection()
        {
            con.Close();
        }
        public void ExecuteQueries(string Query_)
        {
            // Whenever you want to execute a query, like an insert, update or delete
            //query then simply call this function 
            //using the object of a class and pass your query to the function
            SqlCommand cmd = new SqlCommand(Query_, con);
            cmd.ExecuteNonQuery();
        }

        private string dept;
        private string apntmntdate;
        private string apntmnttime;
        private int pid;

        public string Dept
        {
            get
            {
                return dept;
            }

            set
            {
                dept = value;
            }
        }

        public string Apntmntdate
        {
            get
            {
                return apntmntdate;
            }

            set
            {
                apntmntdate = value;
            }
        }

        public string Apntmnttime
        {
            get
            {
                return apntmnttime;
            }

            set
            {
                apntmnttime = value;
            }
        }

        public int Pid
        {
            get
            {
                return pid;
            }

            set
            {
                pid = value;
            }
        }

        public void InsertBooking()
        {
            OpenConection();
            SqlCommand command = new SqlCommand("Select max(b_id) from bookings ", con);
            int b_id;
            object cMax = command.ExecuteScalar();
            if (cMax != DBNull.Value)
            {
                b_id = (int)cMax;
                b_id++;
            }
            else
            {
                b_id = 1;
            }
            string qry = "insert into bookings values (" + b_id + ",@pid,GETDATE(),@deptname,@appointment_date,@appointment_time);";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@deptname", dept);
            cmd.Parameters.AddWithValue("@appointment_date", apntmntdate);
            cmd.Parameters.AddWithValue("@appointment_time", apntmnttime);
            cmd.Parameters.AddWithValue("@pid", pid);


            cmd.ExecuteNonQuery();
        }

    }
}



