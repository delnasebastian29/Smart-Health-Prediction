﻿using System.Web.UI;

namespace HealthPredictionClass.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}