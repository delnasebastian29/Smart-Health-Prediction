﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace HealthPrediction.Class
{
    public class AddDocClass
    {
        string ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["myConn"].ConnectionString;
        SqlConnection con;
        public void OpenConection()
        {
            con = new SqlConnection(ConnectionString);
            con.Open();
        }

        public void CloseConnection()
        {
            con.Close();
        }
        public void ExecuteQueries(string Query_)
        {
            // Whenever you want to execute a query, like an insert, update or delete
            //query then simply call this function 
            //using the object of a class and pass your query to the function
            SqlCommand cmd = new SqlCommand(Query_, con);
            cmd.ExecuteNonQuery();
        }

     
        private string docname;
        private string docgender;
        private string docaddress;
        private string docquaification;
        private string docdepartment;
        private string docemail;
        private string docmobileno;

        public string Docname
        {
            get
            {
                return docname;
            }

            set
            {
                docname = value;
            }
        }

        public string Docgender
        {
            get
            {
                return docgender;
            }

            set
            {
                docgender = value;
            }
        }

        public string Docaddress
        {
            get
            {
                return docaddress;
            }

            set
            {
                docaddress = value;
            }
        }

        public string Docquaification
        {
            get
            {
                return docquaification;
            }

            set
            {
                docquaification = value;
            }
        }

        public string Docdepartment
        {
            get
            {
                return docdepartment;
            }

            set
            {
                docdepartment = value;
            }
        }

        public string Docemail
        {
            get
            {
                return docemail;
            }

            set
            {
                docemail = value;
            }
        }

        public string Docmobileno
        {
            get
            {
                return docmobileno;
            }

            set
            {
                docmobileno = value;
            }
        }

        public void InsertAdddoctor()
        {
            OpenConection();
            SqlCommand command = new SqlCommand("Select max(add_id) from addDoctors ", con);
            int add_id;
            object cMax = command.ExecuteScalar();
            if (cMax != DBNull.Value)
            {
                add_id = (int)cMax;
                add_id++;
            }
            else
            {
                add_id = 1;
            }
            string qry = "insert into addDoctors values (" + add_id + ",@doc_name,@doc_gender,@doc_address,@doc_qualification,@doc_department,@doc_email,@doc_mobileno);";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@doc_name", docname);
            cmd.Parameters.AddWithValue("@doc_gender", Docgender);
            cmd.Parameters.AddWithValue("@doc_address", docaddress);
            cmd.Parameters.AddWithValue("@doc_qualification", docquaification);
            cmd.Parameters.AddWithValue("@doc_department", docdepartment);
            cmd.Parameters.AddWithValue("@doc_email",docemail);
            cmd.Parameters.AddWithValue("@doc_mobileno", docmobileno);
            
            cmd.ExecuteNonQuery();
        }

       
   
        }
    }
