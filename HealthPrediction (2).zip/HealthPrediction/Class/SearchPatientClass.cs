﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace HealthPrediction.Class
{
    public class SearchPatientClass
    {
        string ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["myConn"].ConnectionString;
        SqlConnection con;
        public void OpenConection()
        {
            con = new SqlConnection(ConnectionString);
            con.Open();
        }
        public void CloseConnection()
        {
            con.Close();
        }

        public void ExecuteQueries(string Query_)
        {
            // Whenever you want to execute a query, like an insert, update or delete
            //query then simply call this function 
            //using the object of a class and pass your query to the function
            SqlCommand cmd = new SqlCommand(Query_, con);
            cmd.ExecuteNonQuery();
        }
        private string name;
        private string address;
        private string email;
        private string mobileno;

        public string Name
        {
            get
            {
                return name;
            }

            set
            {
                name = value;
            }
        }

        public string Address
        {
            get
            {
                return address;
            }

            set
            {
                address = value;
            }
        }

        public string Email
        {
            get
            {
                return email;
            }

            set
            {
                email = value;
            }
        }

        public string Mobileno
        {
            get
            {
                return mobileno;
            }

            set
            {
                mobileno = value;
            }
        }
        public DataTable ExecuteSelectQueries()
        {



            OpenConection();
            string qry = "select * from  patientregi  where p_name=@p_name  or p_address= @p_address or p_emailid=@p_emailid or p_mobileno=@p_mobileno ";

            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@p_name", name);
            cmd.Parameters.AddWithValue("@p_address", address);
            cmd.Parameters.AddWithValue("@p_emailid", email);
            cmd.Parameters.AddWithValue("@p_mobileno", mobileno);
            cmd.ExecuteNonQuery();
            DataTable dtReg = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dtReg);
            CloseConnection();
            return dtReg;
        }
    }
}
