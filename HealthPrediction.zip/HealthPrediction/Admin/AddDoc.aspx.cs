﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HealthPrediction.Class;


namespace HealthPrediction.Admin
{
    public partial class AddDoc : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnsave_Click(object sender, EventArgs e)
        {

           
            //   HealthPrediction objReg = new HealthPrediction();
            HealthPrediction.Class.AddDocClass objadd = new HealthPrediction.Class.AddDocClass();
            //   HealthPredictionClass objReg = new HealthPredictionClass();
            objadd.Docname = txtdocname.Text;
            objadd.Docgender = radiomale.Text;
            objadd.Docgender = radiofemale.Text;
            objadd.Docaddress = txtdocaddress.Text;
            objadd.Docquaification = txtqualification.Text;
            objadd.Docdepartment = Department.SelectedItem.Text;
            objadd.Docemail = txtdocemailid.Text;
            objadd.Docmobileno = txtdocmobieno.Text;     
            objadd.InsertAdddoctor();
        }
    }
}
       