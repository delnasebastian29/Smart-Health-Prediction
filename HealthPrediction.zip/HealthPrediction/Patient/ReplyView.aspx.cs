﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using HealthPrediction.Class;

namespace HealthPrediction.Patient
{
    public partial class ReplyView : System.Web.UI.Page
    {

        protected void gv_reply_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        
        protected void Page_Load(object sender, EventArgs e)
        {
            LoadData();
        }
        private void LoadData()
        {
            DataTable dtReg = new DataTable();
            HealthPrediction.Class.HealthPredictionClass objReplyview = new HealthPrediction.Class.HealthPredictionClass();
            dtReg = objReplyview.ReplyView();
            if (dtReg.Rows.Count > 0)
            {
                gv_reply.DataSource = dtReg;
                gv_reply.DataBind();
            }
        }
    }
}