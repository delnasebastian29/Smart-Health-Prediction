﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using HealthPrediction.Class;

namespace HealthPrediction.Patient
{
    public partial class ViewPatient : System.Web.UI.Page
    {
        
        protected void Page_Load(object sender, EventArgs e)
        {
            
                }
          

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void DetailsView1_PageIndexChanging(object sender, DetailsViewPageEventArgs e)
        {
        }
            HealthPrediction.Class.HealthPredictionClass objView = new HealthPrediction.Class.HealthPredictionClass();




       protected void Page_load(object sender, EventArgs e)
        {
            if (HttpContext.Current.Session["PatientId"] == null)
            {
                Response.Redirect("~/Patient/PatientHome.aspx");
            }
            else if (!IsPostBack)
            {
                DataTable dt = new DataTable();
                objView.Pusname = Convert.ToString(Session["PatientId"]);
                dt = objView.showdata();
                if (dt.Rows.Count > 0)
                {
                    dvview.DataSource = dt;
                    dvview.DataBind();

                }
            }
        }
            }




        }
