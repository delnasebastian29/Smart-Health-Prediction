﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HealthPrediction.Class;

namespace HealthPrediction.Patient
{
    public partial class Booking : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnsave_Click(object sender, EventArgs e)
        {
            HealthPrediction.Class.BookingClass objBook = new HealthPrediction.Class.BookingClass();
            //   HealthPredictionClass objReg = new HealthPredictionClass();
            objBook.Dept = Deptsname.SelectedItem.Text;
            objBook.Apntmntdate = txtapntdate.Text;
            objBook.Apntmnttime = txtapnttime.Text;
            objBook.Pid = Convert.ToInt32(Session["PatientId"]);
            objBook.InsertBooking();
    }
}
}
    