﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using HealthPrediction.Class;

namespace HealthPredictionClass.Patient
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnsave_Click1(object sender, EventArgs e)
        {

            DataTable dtReg = new DataTable();
            patientloginClass cobj = new patientloginClass();
            cobj.Username = txtuname.Text;
            cobj.Password = txtpass.Text;
            dtReg = cobj.ExecuteSelectQueries();

            if (dtReg.Rows.Count > 0)
            {
                Session["PatientId"] =Convert.ToString( dtReg.Rows[0][0]);
                lblmsg.Text = " Sucess.";
                Response.Redirect("~/Patient/PatientHome.aspx");

            }
            else
            {
                lblmsg.Text = " Incorrect Try again..!!";
            }
            
        }
    }
}
    
