﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HealthPrediction.Class;

namespace HealthPrediction.Doctor
{
    public partial class DiseasePrediction : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnsave_Click(object sender, EventArgs e)
        {
            HealthPrediction.Class.DiseasepredictionClass objDisease = new HealthPrediction.Class.DiseasepredictionClass();
            //   HealthPredictionClass objReg = new HealthPredictionClass();
            objDisease.Diseaseprediction = txtdp.Text;
       //     objDisease.P_id = Convert.ToInt32(Session["PatientId"]);
         //   objDisease.D_id = Convert.ToInt32(Session["DoctorId"]);

            objDisease.InsertDisease();

        }
    }
}