﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using HealthPrediction.Class;


namespace HealthPrediction.Doctor
{
    public partial class ViewSmessage : System.Web.UI.Page
    {
        
        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        HealthPrediction.Class.DoctorRegClass objMsgview = new HealthPrediction.Class.DoctorRegClass();
        protected void Page_Load(object sender, EventArgs e)
        {
            LoadData();
        }
        private void LoadData()
        {
            DataTable dtReg = new DataTable();
            DoctorRegClass objMsgview = new DoctorRegClass();
            dtReg = objMsgview.MessageView();
            if (dtReg.Rows.Count > 0)
            {
                gv_msg.DataSource = dtReg;
                gv_msg.DataBind();
            }
        }
    }
}