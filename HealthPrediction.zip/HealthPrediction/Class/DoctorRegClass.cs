﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace HealthPrediction.Class
{
    public class DoctorRegClass
    {
        string ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["myConn"].ConnectionString;
        SqlConnection con;
        public void OpenConection()
        {
            con = new SqlConnection(ConnectionString);
            con.Open();
        }
        public void CloseConnection()
        {
            con.Close();
        }
        public void ExecuteQueries(string Query_)
        {
            // Whenever you want to execute a query, like an insert, update or delete
            //query then simply call this function 
            //using the object of a class and pass your query to the function
            SqlCommand cmd = new SqlCommand(Query_, con);
            cmd.ExecuteNonQuery();
        }

        private string dname;
        private string dgender;
        private string daddress;
        private DateTime ddob;
        private string dquaification;
        private string ddepartment;
        private string demail;
        private string dmobileno;
        private string duname;
        private string dpass;

        public string Dname
        {
            get
            {
                return dname;
            }

            set
            {
                dname = value;
            }
        }

        public string Dgender
        {
            get
            {
                return dgender;
            }

            set
            {
                dgender = value;
            }
        }

        public string Daddress
        {
            get
            {
                return daddress;
            }

            set
            {
                daddress = value;
            }
        }

        public DateTime Ddob
        {
            get
            {
                return ddob;
            }

            set
            {
                ddob = value;
            }
        }

        public string Dquaification
        {
            get
            {
                return dquaification;
            }

            set
            {
                dquaification = value;
            }
        }

        public string Ddepartment
        {
            get
            {
                return ddepartment;
            }

            set
            {
                ddepartment = value;
            }
        }

        public string Demail
        {
            get
            {
                return demail;
            }

            set
            {
                demail = value;
            }
        }

        public string Dmobileno
        {
            get
            {
                return dmobileno;
            }

            set
            {
                dmobileno = value;
            }
        }

        public string Duname
        {
            get
            {
                return duname;
            }

            set
            {
                duname = value;
            }
        }

        public string Dpass
        {
            get
            {
                return dpass;
            }

            set
            {
                dpass = value;
            }
        }

        public void InsertDoctor()
        {
            OpenConection();
            SqlCommand command = new SqlCommand("Select max(d_id) from doctorregi ", con);
            int d_id;
            object cMax = command.ExecuteScalar();
            if (cMax != DBNull.Value)
            {
                d_id = (int)cMax;
                d_id++;
            }
            else
            {
                d_id = 1;
            }
            string qry = "insert into doctorregi values (" + d_id + ",@d_name,@d_gender,@d_address,@dob,@d_qualification,@d_department,@d_email,@d_mobileno,@d_username,@d_password);";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@d_name", dname);
            cmd.Parameters.AddWithValue("@d_gender", dgender);
            cmd.Parameters.AddWithValue("@d_address", daddress);
            cmd.Parameters.AddWithValue("@dob", ddob);
            cmd.Parameters.AddWithValue("@d_qualification", dquaification);
            cmd.Parameters.AddWithValue("@d_department", ddepartment);
            cmd.Parameters.AddWithValue("@d_email", demail);
            cmd.Parameters.AddWithValue("@d_mobileno", dmobileno);
            cmd.Parameters.AddWithValue("@d_username", duname);
            cmd.Parameters.AddWithValue("@d_password", dpass);



            cmd.ExecuteNonQuery();
        }


    }
}