﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;


namespace HealthPrediction.Class
{
    public class DiseasepredictionClass
    {
        string ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["myConn"].ConnectionString;
        SqlConnection con;
        public void OpenConection()
        {
            con = new SqlConnection(ConnectionString);
            con.Open();
        }
        public void CloseConnection()
        {
            con.Close();
        }

        public void ExecuteQueries(string Query_)
        {
            // Whenever you want to execute a query, like an insert, update or delete
            //query then simply call this function 
            //using the object of a class and pass your query to the function
            SqlCommand cmd = new SqlCommand(Query_, con);
            cmd.ExecuteNonQuery();
        }
        
        private string p_id;
        private string d_id;
        private string diseaseprediction;

        public string P_id
        {
            get
            {
                return p_id;
            }

            set
            {
                p_id = value;
            }
        }

        public string D_id
        {
            get
            {
                return d_id;
            }

            set
            {
                d_id = value;
            }
        }

        public string Diseaseprediction
        {
            get
            {
                return diseaseprediction;
            }

            set
            {
                diseaseprediction = value;
            }
        }

        public void InsertDisease()
        {
            OpenConection();
            SqlCommand command = new SqlCommand("Select max(diseaseid) from disease_predictions ", con);
            int diseaseid;
            object cMax = command.ExecuteScalar();
            if (cMax != DBNull.Value)
            {
                diseaseid = (int)cMax;
                diseaseid++;
            }
            else
            {
                diseaseid = 1;
            }

        
        string qry = "insert into disease_predictions values (" + diseaseid + ",@pid,@did,@identified_disease);";
        SqlCommand cmd = new SqlCommand(qry, con);
        cmd.Parameters.AddWithValue("@pid", P_id);
            cmd.Parameters.AddWithValue("@did", D_id);
            cmd.Parameters.AddWithValue("@identified_disease", Diseaseprediction);
            
            cmd.ExecuteNonQuery();
        }

}
}