﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace HealthPrediction.Class
{
    public class HealthPredictionClass
    {
        string ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["myConn"].ConnectionString;
        SqlConnection con;
        public void OpenConection()
        {
            con = new SqlConnection(ConnectionString);
            con.Open();
        }
        public void CloseConnection()
        {
            con.Close();
        }

        public void ExecuteQueries(string Query_)
        {
            // Whenever you want to execute a query, like an insert, update or delete
            //query then simply call this function 
            //using the object of a class and pass your query to the function
            SqlCommand cmd = new SqlCommand(Query_, con);
            cmd.ExecuteNonQuery();
        }


        private string pname;
        private string pgender;
        private string paddress;
        private string page;
        private string pbldg;
        private string pemail;
        private string pmobileno;
        private string pusname;
        private string ppass;

        public string Pname
        {
            get
            {
                return pname;
            }

            set
            {
                pname = value;
            }
        }

        public string Pgender
        {
            get
            {
                return pgender;
            }

            set
            {
                pgender = value;
            }
        }

        public string Paddress
        {
            get
            {
                return paddress;
            }

            set
            {
                paddress = value;
            }
        }

        public string Page
        {
            get
            {
                return page;
            }

            set
            {
                page = value;
            }
        }

        public string Pbldg
        {
            get
            {
                return pbldg;
            }

            set
            {
                pbldg = value;
            }
        }

        public string Pemail
        {
            get
            {
                return pemail;
            }

            set
            {
                pemail = value;
            }
        }

        public string Pmobileno
        {
            get
            {
                return pmobileno;
            }

            set
            {
                pmobileno = value;
            }
        }

        public string Pusname
        {
            get
            {
                return pusname;
            }

            set
            {
                pusname = value;
            }
        }

        public string Ppass
        {
            get
            {
                return ppass;
            }

            set
            {
                ppass = value;
            }
        }

        public void InsertPatient()
        {
            OpenConection();
            SqlCommand command = new SqlCommand("Select max(p_id) from patientregi ", con);
            int p_id;
            object cMax = command.ExecuteScalar();
            if (cMax != DBNull.Value)
            {
                p_id = (int)cMax;
                p_id++;
            }
            else
            {
                p_id = 1;
            }


            string qry = "insert into patientregi values (" + p_id + ",@p_name,@p_gender,@p_address,@p_age,@p_bldg,@p_email,@p_mobileno,GETDATE(),@p_username,@p_password);";
            SqlCommand cmd = new SqlCommand(qry, con); 
            cmd.Parameters.AddWithValue("@p_name", pname);
            cmd.Parameters.AddWithValue("@p_gender", pgender);
            cmd.Parameters.AddWithValue("@p_address", paddress);
            cmd.Parameters.AddWithValue("@p_age", page);
            cmd.Parameters.AddWithValue("@p_bldg", pbldg);
            cmd.Parameters.AddWithValue("@p_email", pemail);
            cmd.Parameters.AddWithValue("@p_mobileno", pmobileno);
            cmd.Parameters.AddWithValue("@p_username", pusname);
            cmd.Parameters.AddWithValue("@p_password", ppass);
          //  cmd.Parameters.AddWithValue("@sysdt", );


            cmd.ExecuteNonQuery();
        }

       
        }
    }



